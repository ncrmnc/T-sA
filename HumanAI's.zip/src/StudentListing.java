import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.DefaultCellEditor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.table.*;
import java.util.Comparator;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Collections;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;


public class StudentListing extends JPanel {
    
    private JButton addStudent;
    private JButton closeButton;
    private JButton sortAge;
    private JButton sortLastName;
    private JButton viewClassInfo;
    private JButton deleteStudent;
    private JButton editStudent;
    private JButton markAttendance;
    private JPanel  pnlCommand;
    private JPanel teacherPanel;
    private JCheckBox isPresent;
    private ArrayList<Student> slist;
    private JScrollPane scrollPane;
    private StudentEntry studEntry;
    private EditStudentEntry editStudEntry;
    private StudentListing thisForm;
    private JTable table;
    private DefaultTableModel model;

    /**
     * StudentListing creates an instance of a student listing which displays atable with student
     * @param studEntry
     * @param editStudEntry
     */
    public StudentListing(StudentEntry studEntry, EditStudentEntry editStudEntry) {
        super(new GridLayout(2,1));
        this.studEntry = studEntry;
        this.editStudEntry = editStudEntry;
        thisForm = this;
        
        
        pnlCommand = new JPanel();
    
        slist = loadStudents("student.dat");
        String[] columnNames=  {"Student Id", "Gender","First Name",
                "Last Name",
                "Age",
                "Contact Number", "Days Present",
            "Final Grade", "Letter Grade" };
        
       
    
        model=new DefaultTableModel(columnNames,0);
        table = new JTable(model);
        showTable(slist);
    
        table.setPreferredScrollableViewportSize(new Dimension(900, slist.size()*20 +50));
        table.setFillsViewportHeight(true);
        table.setBackground(new Color(255,255,204));
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(102,255,102));
        DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) table.getTableHeader().getDefaultRenderer();
        renderer.setHorizontalAlignment(JLabel.CENTER);

        scrollPane = new JScrollPane(table);
        add(scrollPane);
    
       
        Font font = new Font("Times New Roman", Font.PLAIN, 12); // Create a new font object
        addStudent  = new JButton("Add Student");
        addStudent.setFont(font);
        addStudent.setBackground(new Color(102,255,102));
        sortAge  = new JButton("Sort by Age");
        sortAge.setFont(font);
        sortAge.setBackground(new Color(102,255,102));
        closeButton   = new JButton("Close");
        closeButton.setFont(font);
        closeButton.setBackground(new Color(102,255,102));
        sortLastName = new JButton("Sort by Last Name");
        sortLastName.setFont(font);
        sortLastName.setBackground(new Color(102,255,102));
        deleteStudent  = new JButton("Delete Student");
        deleteStudent.setFont(font);
        deleteStudent.setBackground(new Color(102,255,102));
        editStudent  = new JButton("Edit Student");
        editStudent.setFont(font);
        editStudent.setBackground(new Color(102,255,102));
        markAttendance = new JButton("Take Attendance");
        markAttendance.setFont(font);
        markAttendance.setBackground(new Color(102,255,102));
        viewClassInfo  = new JButton("Class Info");
        viewClassInfo.setFont(font);
        viewClassInfo.setBackground(new Color(102,255,102));
        

        closeButton.addActionListener(new CloseButtonListener());
        addStudent.addActionListener(new AddButtonListener());
        sortAge.addActionListener(new SortAgeListener());
        sortLastName.addActionListener(new SortLastNameListener());
        editStudent.addActionListener(new EditButtonListener());
        deleteStudent.addActionListener(new DeleteButtonListener());
        markAttendance.addActionListener(new markAttendanceListener());
        viewClassInfo.addActionListener(new viewClassInfoListener());
        

        
        
        pnlCommand.add(addStudent);
        pnlCommand.add(closeButton);
        pnlCommand.add(sortAge);
        pnlCommand.add(sortLastName);
        pnlCommand.add(editStudent);
        pnlCommand.add(deleteStudent);
        pnlCommand.add(markAttendance);
        pnlCommand.add(viewClassInfo);

        
       
        add(pnlCommand);

    }

    
    /** 
     * @param slist
     */
    private void showTable(ArrayList<Student> slist)
    {
       for (Student student : slist){
        addToTable(student);
       } 

    }
    
    /** 
     * @param s
     */
    private void addToTable(Student s)
    {
        String[] item={s.getId()+"", s.getGender(), s.getFirstName(),s.getLastName(), ""+ s.getAge(),""+s.getContactNum(), ""+s.getNumDaysPresent(), "" + s.getFinalGrade()+"" , s.getLetterGrade()};
        model.addRow(item);        
        
    }


    public void addStudent(Student s)
    {
        slist.add(s);
        addToTable(s);
        

    }

    private ArrayList<Student> loadStudents(String studentFile)
    {
        Scanner studentScan = null;
        ArrayList<Student> slist = new ArrayList<Student>();
        try
        {
            studentScan  = new Scanner(new File(studentFile));
            while(studentScan.hasNext())
            {
                String [] nextLine = studentScan.nextLine().split(" ");
                String gender = nextLine[0];
                String firstName = nextLine[1];
                String lastName = nextLine[2];
                int age = Integer.parseInt(nextLine[3]);
                String emergencyContact = nextLine[4];
                int numDaysPresnt = Integer.parseInt(nextLine[5]);
                int finalGrade = Integer.parseInt(nextLine[6]);

                
                

                Student s = new Student(firstName, lastName, age, gender, finalGrade, emergencyContact, numDaysPresnt);
                slist.add(s);
            }

            studentScan.close();
        }
        catch(IOException e)
        {}
        return slist;
    }


    private class CloseButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            int choice = JOptionPane.showOptionDialog(null, "Are you sure you want to exit the program?", "Exit Confirmation", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, new String[]{"Yes", "No"}, "OK");

        switch (choice) {
            case JOptionPane.NO_OPTION:
                break;
            case JOptionPane.YES_OPTION:  
                System.exit(0);
                break;
            default:
                break;
        }

    }
}
    
    private class AddButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            StudentEntry se = new StudentEntry(thisForm);
          
            
        }
    }

    private class viewClassInfoListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            JFrame teacherFrame = new JFrame("Class Information");
            JPanel teacherPanel = new JPanel(new GridBagLayout());
            teacherPanel.setPreferredSize(new Dimension(700, 500));
            teacherPanel.setBackground(new Color(102, 255, 102));
    
            JLabel teacherName = new JLabel("Teacher: Miss Francis");
            int count = 0;
            for (Student s : slist) {
                count++;
            }
            JLabel numStudentsLabel = new JLabel("Number of Students: " + count);
            JLabel subjectTaught = new JLabel("Subject Taught: Information Technology");
            teacherName.setFont((new Font("Serif", Font.BOLD, 20)));
            numStudentsLabel.setFont((new Font("Serif", Font.BOLD, 20)));
            subjectTaught.setFont((new Font("Serif", Font.BOLD, 20)));
    
            ImageIcon icon = new ImageIcon("image.png");
            Image image = icon.getImage().getScaledInstance(280, 230, Image.SCALE_SMOOTH);
            icon = new ImageIcon(image);
            JLabel iconLabel = new JLabel(icon);
    
            GridBagConstraints parts = new GridBagConstraints();
            parts.anchor = GridBagConstraints.CENTER;
            parts.insets = new Insets(20, 20, 20, 20);
    
            parts.gridx = 0;
            parts.gridy = 0;
            parts.insets.top = 10;
            parts.insets.bottom = 10;
            teacherPanel.add(iconLabel, parts);
    
            parts.gridx = 0;
            parts.gridy = 1;
            parts.insets.top = 10;
            parts.insets.bottom = 10;
            teacherPanel.add(teacherName, parts);
    
            parts.gridx = 0;
            parts.gridy = 2;
            parts.insets.top = 10;
            parts.insets.bottom = 10;
            teacherPanel.add(numStudentsLabel, parts);
    
            parts.gridx = 0;
            parts.gridy = 3;
            parts.insets.top = 10;
            parts.insets.bottom = 10;
            teacherPanel.add(subjectTaught, parts);

    
            teacherFrame.add(teacherPanel);
    
            teacherFrame.pack();
            teacherFrame.setVisible(true);
            teacherFrame.setLocationRelativeTo(null);
        }
    }

    

    private class DeleteButtonListener implements ActionListener {
        
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(StudentListing.this, "Please select a row to delete.");
            } else {
                int confirm = JOptionPane.showConfirmDialog(StudentListing.this, "Are you sure you want to delete this student?",
                        "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    model.removeRow(selectedRow);
                    

                    try {
                        FileWriter writer = new FileWriter("student.dat");
                
                        
                        for (int i = 1; i <model.getRowCount(); i++) {
                            for (int j = 1; j <model.getColumnCount()-1; j++) {
                                writer.write(model.getValueAt(i, j).toString() + " ");
                                
                            }
                            writer.write("\n");
                        }
                        writer.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(StudentListing.this, "Error while updating data file.");
                    }

                    
        }
    
    }
}

    }
    
    
    
    

    private class EditButtonListener implements ActionListener 
    {
        public void actionPerformed(ActionEvent e)
        {

        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(StudentListing.this, "Please select a row to edit.");
        } else{
            
                
                EditStudentEntry ese = new EditStudentEntry(thisForm);
                try {
                    FileWriter writer = new FileWriter("student.dat", true);
                    for (int i = 1; i <model.getRowCount(); i++) {
                        for (int j = 1; j <model.getColumnCount()-1; j++) {
                            writer.write(model.getValueAt(i, j).toString() + " ");
                            model.removeRow(selectedRow);


                        }
                        writer.write("\n");
                        
                    }
                    writer.close();
                    
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(StudentListing.this, "Error while updating data file.");
                } catch (ArrayIndexOutOfBoundsException aob) {}
                
                   
                    
                }
            }
        }
            

        private class markAttendanceListener implements ActionListener {
            public void actionPerformed(ActionEvent e) {
                JFrame attendanceFrame = new JFrame("Student Register");
                JTable attendanceTable = new JTable();
                isPresent = new JCheckBox();
        
                DefaultTableModel mod = new DefaultTableModel(new Object[]{"First Name", "Last Name", "Attendance"}, 0);
        
                for (Student student : slist) {
                    mod.addRow(new Object[]{student.firstName, student.lastName, false});
                }
        
                attendanceTable.setModel(mod);
                JTableHeader header = attendanceTable.getTableHeader();
                header.setBackground(new Color(102,255,102));
                DefaultTableCellRenderer renderer = (DefaultTableCellRenderer) attendanceTable.getTableHeader().getDefaultRenderer();
                renderer.setHorizontalAlignment(JLabel.CENTER);
        
                TableColumn attendanceColumn = attendanceTable.getColumnModel().getColumn(2);
                attendanceColumn.setCellRenderer(attendanceTable.getDefaultRenderer(Boolean.class));
                attendanceColumn.setCellEditor((TableCellEditor) new DefaultCellEditor(isPresent));
        
                attendanceFrame.add(new JScrollPane(attendanceTable));
                JButton saveButton = new JButton("Register");
                saveButton.setBackground(new Color(102,255,102));
                saveButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JFrame mainFrame = (JFrame) SwingUtilities.getWindowAncestor(thisForm);
        
                        DefaultTableModel mainTableModel = (DefaultTableModel) table.getModel();
                        
        
                        for (int row = 0; row < attendanceTable.getRowCount(); row++) {
                            String studentFName = (String) attendanceTable.getValueAt(row, 0);
                            String studentLName = (String) attendanceTable.getValueAt(row, 1);
                            boolean attendance = (boolean) attendanceTable.getValueAt(row, 2);
        
        
                            for (int i = 0; i < mainTableModel.getRowCount(); i++) {
                                if (mainTableModel.getValueAt(i, 2).equals(studentFName) && mainTableModel.getValueAt(i, 3).equals(studentLName)) {
                                    String numDaysPresent =  (String) mainTableModel.getValueAt(i, 6);
                                    
                                    if (attendance) {
                                        int num = Integer.parseInt(numDaysPresent)+1;
                                        mainTableModel.setValueAt(Integer.toString(num), i, 6);
                                        attendanceFrame.dispose();
                                        
                                        try {
                                            Path filePath = Paths.get("student.dat");
                                            ArrayList<String> fileContent = new ArrayList<>(Files.readAllLines(filePath, StandardCharsets.UTF_8));
                                            for (int j = 0; j < fileContent.size(); j++) {
                                                if (attendanceTable.getValueAt(j, 0).equals(studentFName) && attendanceTable.getValueAt(j, 1).equals(studentLName)){
                                                    String[] parts = fileContent.get(j).split(" ");
                                                    parts[5] = String.valueOf(num);
                                                    fileContent.set(j, String.join(" ", parts));
                                                }
                                                
                                                    

                                                    
                                                
                                            }
                                            
                                            Files.write(filePath, fileContent, StandardCharsets.UTF_8);
                                        } catch (IOException ex) {
                                        } catch (ClassCastException cce){
                                        }
        
                                    }
                                    break;
                                }
                            }
                        }
                    }
                });
                attendanceFrame.add(saveButton, BorderLayout.SOUTH);
                attendanceFrame.pack();
                attendanceFrame.setVisible(true);
                attendanceFrame.setLocationRelativeTo(null);
            }
        }



    private class SortAgeListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            Collections.sort(slist, new Comparator <Student>(){
                public int compare (Student s1 , Student s2){
                    return Integer.compare(s1.getAge(), s2.getAge());
                }
            });
            model.setRowCount(0);
            showTable(slist);
                            
                        
                    }
                }
                  
    private class SortLastNameListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
                Collections.sort(slist, new Comparator <Student>(){
                public int compare (Student s1 , Student s2){
                   String [] name = s1.getLastName().split(" ");
                   String LName1 = name[0];
                   String [] name2 = s2.getLastName().split(" ");
                   String LName2 = name2[0];
                   return LName1.compareTo(LName2);
                }
            });
            model.setRowCount(0);
            showTable(slist);
            
            


    
            
         
        }
            
          
            
        }



        
}
    


