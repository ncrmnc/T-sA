import java.lang.Exception;  
import java.awt.*;  
import javax.swing.*; 
import javax.swing.ImageIcon;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.Dimension;



class LoginForm extends JFrame
{   
    JButton logInButton;  
    JPanel newPanel;  
    JFrame frame;
    private StudentEntry studEntry;
   
    
    
    
    

    /**
     * 
     * @param studEntry
     */
    LoginForm(StudentEntry studEntry)  

    {   
        setTitle("Teacher's Aide");
        this.studEntry = studEntry;
        frame = this;
        ImageIcon icon = new ImageIcon("image.png");
        Image image = icon.getImage().getScaledInstance(280, 230, Image.SCALE_SMOOTH);
        icon = new ImageIcon(image); 
        JLabel iconLabel = new JLabel(icon);
        
        logInButton = new JButton("Enter Class"); 
        
        newPanel = new JPanel(new GridBagLayout());
        GridBagConstraints parts = new GridBagConstraints();
        parts.anchor = GridBagConstraints.WEST;
        parts.insets = new Insets(20, 20, 20, 20);

        parts.gridx = 1;
        parts.gridy = 0;  
        parts.anchor = GridBagConstraints.CENTER;   
        newPanel.add(iconLabel, parts);
 
        parts.gridx = 0;
        parts.gridy = 3;
        parts.gridwidth = 2;
        parts.anchor = GridBagConstraints.CENTER;


        newPanel.add(logInButton, parts);
        logInButton.setPreferredSize(new Dimension(100, 30));
        logInButton.setBackground(Color.blue);
        logInButton.addActionListener(new EnterClassButtonListener());
         
    
        newPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "Teacher Login"));
        newPanel.setBackground(new Color(102,255,102));
        add(newPanel);
        pack();
        setLocationRelativeTo(null);
             
    }  
    
      
    private class EnterClassButtonListener implements ActionListener{
        
        
        public void actionPerformed(ActionEvent e)     
    {  
        StudentListing slisting = new StudentListing(null, null);

        
        frame.setContentPane(slisting);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setBackground(new Color(255,255,204));
        
        }
    }  

    


/** 
 * @param args
 */
public static void main(String[] args) {
    try {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    } catch (Exception ex) {
        ex.printStackTrace();
    }
     
    SwingUtilities.invokeLater(new Runnable() {
        @Override
        public void run() {
            new LoginForm(null).setVisible(true);
        }
    });
}
} 