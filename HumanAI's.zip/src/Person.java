
public abstract class Person{

    private String gender;
    protected String firstName, lastName;
	private int age;
	private int id = 1210000; 
    
		/**
		 * @param fName
		 * @param lName
		 * @param age
		 * @param gend
		*/ 
		public Person(String fName, String lName, int age, String gend)
		{
			firstName = fName;
            lastName = lName;
            gender = gend;
            this.age = age;
			
           
        }
		
		
		/** 
		 * @return int
		 */
		public int getAge()
		{
			return age;
		}

        public String getGender(){
            return gender;
        }
        

		public abstract int getId();
		public abstract String getFirstName();
		public abstract String getLastName();
        
		

	
}