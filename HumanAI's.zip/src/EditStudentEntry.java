import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

public class EditStudentEntry extends JFrame {
    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtAge;     
    private JTextField txtFinalGrade;  
    private JTextField emergencyContact;
    private JComboBox<String> genderComboBox;
    private JButton saveButton;
    private JButton closeButton;
    private JButton clearButton;
    private StudentListing slisting;
    private JPanel pnlCommand;
    private JPanel pnlDisplay;
    
    
    /**
     * Edit StudentEntry constructor displays a student entry panel 
     * @param slisting
     */
    public EditStudentEntry(StudentListing slisting)
    {
        StudentListing sl = new StudentListing(null, null);
        this.slisting = slisting;
        setTitle("Editing existing student");
        pnlCommand = new JPanel();
        pnlDisplay = new JPanel();
        pnlDisplay.add(new JLabel("  First Name:")); 
        txtFirstName = new JTextField(20);
        pnlDisplay.add(txtFirstName);

        pnlDisplay.add(new JLabel("  Last Name:")); 
        txtLastName = new JTextField(20);
        pnlDisplay.add(txtLastName);

        pnlDisplay.add(new JLabel("  Age:"));
        txtAge = new JTextField(20);
        pnlDisplay.add(txtAge);

        pnlDisplay.add(new JLabel("  Final Grade:"));
        txtFinalGrade = new JTextField(20);
        pnlDisplay.add(txtFinalGrade);

        pnlDisplay.add(new JLabel("  Emergency Contact Number:"));
        emergencyContact = new JTextField(20);
        pnlDisplay.add(emergencyContact);


        pnlDisplay.add(new JLabel("  Select Gender:"));
        String[] genders = {"", "Male", "Female", "Non-binary"};
        genderComboBox = new JComboBox<>(genders);
        pnlDisplay.add(genderComboBox);
        
        pnlDisplay.setLayout(new GridLayout(8,0));
        
       
        saveButton = new JButton("Save");
        closeButton = new JButton("Close");
        saveButton.setBackground(new Color(102,255,102));
        closeButton.setBackground(new Color(102,255,102));

        saveButton.addActionListener(new SaveButtonListener());
        closeButton.addActionListener(new CloseButtonListener());

        pnlCommand.add(saveButton);
        pnlCommand.add(closeButton);
        add(pnlDisplay, BorderLayout.CENTER);
        add(pnlCommand, BorderLayout.SOUTH);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);

    }

    private class SaveButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
           
            String txt1 = txtFirstName.getText();
            String txt2 = txtLastName.getText();
            String txt3 = txtAge.getText();
            String txt4 = txtFinalGrade.getText();
            String txt5 = emergencyContact.getText();
            String txt6 = (String) genderComboBox.getSelectedItem();

        
           
            try{
                if (txt1.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "First Name field is empty!");
                    throw new Exception();
                    
                }
                if (txt2.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Last Name field is empty!");
                    throw new Exception();
                }
                if (txt3.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Age field is empty!");
                    throw new Exception();
                }
                if (txt4.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Final Grade field is empty!");
                    throw new Exception();
                }
                if (txt5.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Emergency Contact field is empty");
                    throw new Exception();
                }
                if (txt6.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please select a gender!");
                    throw new Exception();
                }

                Integer.parseInt(txt3);
                Integer.parseInt(txt4);
                Long.parseLong(txt5);
                Student s = new Student(txt1, txt2, Integer.parseInt(txt3), txt6, Integer.parseInt(txt4), txt5, 0);
                slisting.addStudent(s);
                setVisible(false);
            } catch(NumberFormatException nfe) {} catch (Exception e1) {
                System.out.println(e1.getMessage());
            }
            
        
        try {
            
            FileWriter fileWriter = new FileWriter("student.dat", true);

            BufferedWriter writer = new BufferedWriter(fileWriter);
            
            writer.write("\n");
            writer.write(txt6 + " ");
            writer.write(txt1 + " ");
            writer.write(txt2+ " ");
            writer.write(txt3);
            writer.write(" ");
            writer.write(txt5);
            writer.write(" ");
            writer.write("0");
            writer.write(" ");
            writer.write(txt4);

            writer.flush();
            writer.close();
            
        } catch (IOException ioe) {
           
        }

        }

        

        

        
    
}
private class CloseButtonListener implements ActionListener
        {
            public void actionPerformed(ActionEvent e)
            {
                System.exit(0);
                setVisible(false);
            
            }
    
        }

    
    /** 
     * @return String[]
     */
    public String [] getStudentData(){
        String txt1 = txtFirstName.getText();
        String txt2 = txtLastName.getText();
        String txt3 = txtAge.getText();
        String txt4 = txtFinalGrade.getText();
        String txt5 = emergencyContact.getText();
        String txt6 = (String) genderComboBox.getSelectedItem();
        String [] studentData = {txt1, txt2, txt3, txt6, txt4, txt5};
        return studentData;
    }


        

}