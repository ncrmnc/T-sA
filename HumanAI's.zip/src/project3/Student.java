package project3;

import java.util.Random;

public class Student extends Person{
    private int finalGrade;
    private String letterGrade;
    private String emergencyContact;
    private int numDaysPresent;
    private static int studentId = 0;
    private int id;

    /**
     * Student constructirs creates an instance of a student with the following parameters.
     * @param firstName
     * @param lastName
     * @param age
     * @param gend
     * @param finalGrade
     * @param contactNum
     * @param numDaysPresent
     */
    public Student(String firstName, String lastName, int age, String gend, int finalGrade, String contactNum, int numDaysPresent){
        super(firstName, lastName, age, gend);
        this.finalGrade = finalGrade;
        emergencyContact = contactNum;
        this.numDaysPresent = numDaysPresent;
        this.id = ++studentId;
        
        
    }

    
    /** 
     * @return String
     */
    public String getFirstName(){
        return firstName;
    }

    public String getLastName(){
        return lastName;
    }


    public int getFinalGrade(){
        return finalGrade;
    }

    public int getNumDaysPresent(){
        return numDaysPresent;
    }

    public String getLetterGrade(){
        if (finalGrade >= 90){
            letterGrade = "A+";
        } else if (finalGrade >= 80){
            letterGrade = "A";
        } else if (finalGrade >= 70){
            letterGrade = "B+";
        } else if (finalGrade >= 60){
            letterGrade = "B";
        } else if (finalGrade >= 50){
            letterGrade = "C";
        } else{
            letterGrade = "F";
        }
        return letterGrade;
    }
    public String getContactNum(){
        
        return emergencyContact;
    }

    public int getId() {
        return 100000 + this.id;
    }

    
       

   
    

    


}