import java.util.Random;

public class Teacher extends Person{

    private String className;
    private String subjectTaught;
    private int numStudents;
    private static int teacherId = 0;
    private int id;

    /**
     * Teacher constructor creates an instance of a teacher with the following parameters.
     * @param firstName
     * @param lastName
     * @param age
     * @param gend
     * @param className
     * @param subjectTaught
     * @param numStudents
     */
    public Teacher(String firstName, String lastName, int age, String gend, String className, String subjectTaught, int numStudents){
        super(firstName, lastName, age, gend);
        this.className = className;
        this.subjectTaught = subjectTaught;
        this.numStudents = numStudents;
        this.id = ++teacherId;
    }

    
    /** 
     * @return String
     */
    public String getFirstName(){
        return firstName;
    }

    public String getLastName(){
        return lastName;
    }

    public int getId() {
        return 50000 + this.id;
    }
    public int getNumStudents(){
        return numStudents;
    }

    public String getContactNum(){
        return subjectTaught;
    }

    public String getClassName(){
        return className;
    }
       
    
}
